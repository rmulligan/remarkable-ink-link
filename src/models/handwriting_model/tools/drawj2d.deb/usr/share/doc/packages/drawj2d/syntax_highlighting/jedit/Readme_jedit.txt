Syntax Highlighting in the editor "jEdit"
-----------------------------------------

JEdit is a free editor written in java. It runs on Linux, Macintosh, Windows and Unix.
The release 5.4 supports syntax highlighting for Drawj2d files out of the box.

Using
- Open your drawj2d template in jEdit
- Menu "Utilities->Buffer Options->Edit mode", choose "drawj2d"

Update of syntax file
- install jEdit
- copy the file "drawj2d.xml"
  to the program folder jedit/modes (replace the existing file)




Syntax-Hervorhebung im Editor "jEdit"
-------------------------------------

JEdit ist ein freier Texteditor. Er ist in Java geschrieben und läuft auf Linux, Macintosh, Windows und Unix.
Die Version 5.4 bringt standardmässig Drawj2d-Syntax-Hervorhebung mit.

Gebrauch
- In jEdit eine Drawj2d-Vorlage öffnen
- Menü "Utilities->Buffer Options->Edit mode", "drawj2d" wählen

Update der Syntax-Datei
- jEdit installieren
- die Datei "drawj2d.xml"
  ins Programmverzeichnis jedit/modes kopieren (Datei ersetzen)
